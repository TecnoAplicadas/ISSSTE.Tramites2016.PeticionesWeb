﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos;

namespace ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas
{
    public class clsGenero:Genero
    {
        public new Nullable<int> IdGenero { get; set; }
    }
}
