﻿using ISSSTE.TramitesDigitales2016.Modelos.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas
{
    public class clsTipoDerechoHabiente:TipoDerechohabiente
    {
        public new Nullable<int> IdTipoDerechohabiente { get; set; }
    }
}
