﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISSSTE.TramitesDigitales2016.Modelos.Interfaces
{
   public interface ICatalogo
   {
      string Clave { get; set; }
      string Nombre { get; set; }
   }
}
