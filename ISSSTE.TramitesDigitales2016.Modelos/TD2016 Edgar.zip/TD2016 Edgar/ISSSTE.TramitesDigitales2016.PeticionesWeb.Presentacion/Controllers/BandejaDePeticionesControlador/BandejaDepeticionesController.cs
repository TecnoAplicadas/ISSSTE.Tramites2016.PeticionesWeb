﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ISSSTE.TramitesDigitales2016.Modelos.Contextos;
using ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.BandejaPeticionesRdn;
using PagedList;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Procesos.Modulos.BandejaPeticiones;
using System.Text.RegularExpressions;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.Catalogos;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Models;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers.BandejaDePeticionesControlador
{
    public class BandejaDepeticionesController : Controller
    {
        #region Variables
        BandejaDePeticionesRdn BandejaDePeticionesc = new BandejaDePeticionesRdn();

        private List<pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Usuario_Result> ListPeticiones =
            new List<pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Usuario_Result>();

        private List<pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Filtros_Result> ListPeticionesFiltradas =
            new List<pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Filtros_Result>();

        private List<pa_PeticionesWeb_Bandeja_Peticiones_Obtiene_Operador_Por_UPS_Result> ListOperadores =
            new List<pa_PeticionesWeb_Bandeja_Peticiones_Obtiene_Operador_Por_UPS_Result>();

        private int IdUsuarioIniciodeSeseion =  0;

        #endregion

        public ActionResult BandejaIndex
        (string sortOrder, string currentFilter, string searchString, int? page)
        {

            ListPeticiones.Clear();

            List<pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Filtros_Result> PeticionesEncontradas =
           (List<pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Filtros_Result>)TempData["PeticionesFiltradas"];

            clsUsuario UsuarioAccesado = new clsUsuario();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            UsuarioAccesado.IdUsuario = 2;
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";


            if (PeticionesEncontradas != null)
            {
                foreach (pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Filtros_Result item in PeticionesEncontradas)
                {
                    pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Usuario_Result PeticionEnlazada
                    = new pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Usuario_Result();

                    PeticionEnlazada.IdOperador = item.IdOperador;
                    PeticionEnlazada.IdPeticion = item.IdPeticion;
                    PeticionEnlazada.Folio = item.Folio;
                    PeticionEnlazada.UPSNombre = item.UPSNombre;
                    PeticionEnlazada.FechaHechos = item.FechaHechos;
                    PeticionEnlazada.CausaAsunto = item.CausaAsunto;
                    PeticionEnlazada.NombreUsuario = item.NombreUsuario;
                    PeticionEnlazada.IdUPS = item.IdUPS;
                    PeticionEnlazada.SemaforoPeticion = item.SemaforoPeticion;
                    PeticionEnlazada.IdEstatusInterno = item.IdEstatusInterno;

                    ListPeticiones.Add(PeticionEnlazada);
                }
            }
            else
            {
                ListPeticiones = BandejaDePeticionesc.Obtener_Peticiones_UsuarioRdn(UsuarioAccesado, errorProcedimientoAlmacenado).ToList();
            }
            var VarListaPeticiones = ListPeticiones;


            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            if (!String.IsNullOrEmpty(searchString))
            {
                VarListaPeticiones = (VarListaPeticiones.Where(s => s.Folio.Contains(searchString)|| s.UPSNombre.Contains(searchString))).ToList();
            }
            switch (sortOrder)
            {
                case "name_desc":
                    VarListaPeticiones = (VarListaPeticiones.OrderByDescending(s => s.Folio)).ToList();
                    break;
                case "Date":
                    VarListaPeticiones = (VarListaPeticiones.OrderBy(s => s.UPSNombre)).ToList();
                    break;
                case "date_desc":
                    VarListaPeticiones = VarListaPeticiones.OrderByDescending(s => s.UPSNombre).ToList();
                    break;
                default:  // Name ascending 
                    VarListaPeticiones = VarListaPeticiones.OrderBy(s => s.Folio).ToList();
                    break;
            }

            int pageSize = 6;
            int pageNumber = (page ?? 1);

            return View(VarListaPeticiones.ToPagedList(pageNumber, pageSize));
        }
        public ActionResult AsignarOperador()
        {
            clsPeticion pEntrada = new clsPeticion();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            pEntrada.IdUnidadPrestadoraServicio = 1;

            string FolioPeticion = Request["IdFolioPar"].ToString();
            string IdUPS = Request["IdUPSPar"].ToString();
            TempData["IdPeticion"] = Request["IdPeticion"].ToString(); ;

            ListOperadores = BandejaDePeticionesc.ObtieneOperadorPorUnidadRdn(pEntrada, errorProcedimientoAlmacenado).ToList();
            //TempData["PeticionesFiltradas"] = ListPeticionesFiltradas;
            //var Formulariovar = Formulario.GetValue("Folio");

            return View(ListOperadores);
        }

        [HttpPost]
        public ActionResult AsignarOperador
        (pa_PeticionesWeb_Bandeja_Peticiones_Obtiene_Operador_Por_UPS_Result Formulario)
        {
            //var Formulariovar = Formulario.AllKeys;
            //string FolioPeticion = Request["IdFolioPar"].ToString();
            //Formulario.IdUsuario.ToString();
            string IdUsuario = Formulario.NombreOperador.ToString().Substring(14);
            IdUsuario = Regex.Replace(IdUsuario, "}","");
            int Idusuario = Convert.ToInt32(IdUsuario);
            clsUsuario ParametrosUsuario = new clsUsuario();
            clsPeticion pEntrada = new clsPeticion();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            ParametrosUsuario.IdUsuario = 2;
            pEntrada.IdOperador = Idusuario;
            pEntrada.IdPeticion =Convert.ToInt32(TempData["IdPeticion"]);
            bool OperadorNuevoReasignado  = Convert.ToBoolean(TempData["Reasigancionoperador"]);

            BandejaDePeticionesc.AsignarOperadorRdn(ParametrosUsuario, pEntrada, OperadorNuevoReasignado,  errorProcedimientoAlmacenado);

            //string OperadorSelecionado = Request["NombreOperador"].ToString();
            // var Formulariovar = Formulario.AllKeys;

            return RedirectToAction("BandejaIndex");
        }

        public ActionResult BuscarPeticion()
        {
            clsUsuario ParamPeticion = new clsUsuario();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            List<pa_PeticionesWeb_Catalogos_EsatusInterno_Result> CatalogoEstatus =
            new List<pa_PeticionesWeb_Catalogos_EsatusInterno_Result>();

            pa_PeticionesWeb_Catalogos_EsatusInterno_Result OpcionSeleccione =
            new pa_PeticionesWeb_Catalogos_EsatusInterno_Result();

            OpcionSeleccione.IdEstatusInterno = 0;
            OpcionSeleccione.Nombre = "<Seleccione>";

            ParamPeticion.IdUsuario = 2;
            ViewModelBuscarPeticion VistaBuscar = new ViewModelBuscarPeticion();            
            

            CatalogoEstatus = BandejaDePeticionesc.ObtenerCatalogoEstatusInternoRdn(ParamPeticion, errorProcedimientoAlmacenado);
            CatalogoEstatus.Add(OpcionSeleccione);
            //CatalogoEstatus.OrderBy(I => I.IdEstatusInterno);
            ViewBag.CatalogoEstatusInternoRdn = new SelectList(CatalogoEstatus.OrderBy(I => I.IdEstatusInterno), "IdEstatusInterno", "Nombre");

            return View();
        }

        [HttpPost]
        public ActionResult BuscarPeticion(FormCollection Formulario)
        {
            FiltrosPeticion pEntrada = new FiltrosPeticion();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            pEntrada.IdUsuario = 2;
            pEntrada.Folio = Request["FoliotTxt"].ToString();
            pEntrada.IdEstatusInterno = Convert.ToInt32(Request["CatalogoEstatusInternoRdn"]);

            #region Datos del peticionario
            pEntrada.Curp = Request["curpPetTxt"].ToString();            
            pEntrada.Rfc =  Request["rfcPetTxt"].ToString(); 
            pEntrada.Nombre = Request["nombreTxt"].ToString();
            pEntrada.ApellidoPaterno = Request["apPaternoTxt"].ToString();
            pEntrada.ApellidoMaterno = Request["apMaternoTxt"].ToString();
            //pEntrada.IdGenero = Convert.ToInt16(Request["sexoSlct"]);
            //pEntrada.IdTipoDerechohabiente = Convert.ToInt16(Request["tipoDerSlct"]);
            #endregion

            #region Datos de contacto
            pEntrada.ClaveCP = Request["codPostTxt"].ToString();
            //pEntrada.IdEstado = Convert.ToInt16(Request["estadoSlct"]);
            //pEntrada.IdMunicipio = Convert.ToInt16(Request["municipioSlct"]);
            pEntrada.NombreColonia = (string.IsNullOrEmpty(Request["coloniaTxt"].ToString())) ? "": Request["coloniaTxt"].ToString();
            pEntrada.Calle = (string.IsNullOrEmpty(Request["calleTxt"].ToString())) ? "" : Request["calleTxt"].ToString();
            pEntrada.NumeroExterior = Request["numExtTxt"].ToString();
            pEntrada.NumeroInterior = Request["numIntTxt"].ToString();
            pEntrada.Lada = Request["ladaTxt"].ToString();
            pEntrada.TelefonoFijo = Request["telefTxt"].ToString();
            pEntrada.TelefonoMovil = Request["celTxt"].ToString();
            pEntrada.CorreoElectronico = Request["emailTxt"].ToString();
            #endregion

            #region Datos del afectado
            pEntrada.CurpAfectado = Request["curpAfectadoTxt"].ToString();
            pEntrada.RfcAfectado = Request["rfcAfectadoTxt"].ToString();
            pEntrada.NombreAfectado = Request["afecNomTxt"].ToString();
            pEntrada.ApellidoPaternoAfectado = Request["afecApPatTxt"].ToString();
            pEntrada.ApellidoMaternoAfectado = Request["afecApMatTxt"].ToString();
            //pEntrada.IdGeneroAfectado = Convert.ToInt16(Request["afecSexoSlct"]);
            //pEntrada.IdTipoDhbAfectado = Convert.ToInt16(Request["afecTipoDerSlct"]);
            pEntrada.TelefonoFijoAfectado = Request["afecTelTxt"].ToString();
            pEntrada.CorreoElectronicoAfectado = Request["afecEmailTxt"].ToString();
            #endregion

            #region Descripción de la petición
            //pEntrada.IdTipoUps = Convert.ToInt16(Request["areaPeticionSlct"]);                       //area
            //pEntrada.IdUnidadAdministrativa = Convert.ToInt16(Request["delPeticionSlct"]);          //delegacion
            //pEntrada.IdUnidadPrestadoraServicio = Convert.ToInt16(Request["unidadPeticionSlct"]);
            //pEntrada.IdTipoOpinion = Convert.ToInt16(Request["opinionPetSlct"]);
            //pEntrada.IdCausaAsunto = Convert.ToInt16(Request["asuntoPetSlct"]);
            //pEntrada.FechaHechos = Request["hechosdatePicker"].ToString();
            //pEntrada.IdServicioHecho = Convert.ToInt16(Request["servicioHechoSlct"]);
            pEntrada.Descripcion = Request["descTxtArea"].ToString();
            #endregion

            ListPeticionesFiltradas = BandejaDePeticionesc.Obtener_Peticiones_FiltrosRdn(pEntrada, errorProcedimientoAlmacenado).ToList();
            TempData["PeticionesFiltradas"] = ListPeticionesFiltradas;

            return RedirectToAction("BandejaIndex");
        }

        //[HttpPost]
        //public ActionResult BuscarPeticion(FormCollection Formulario)
        //{
        //    //string FolioPeticion = Request["IdFolioPar"].ToString();
        //    //string IdUPS = Request["IdUPSPar"].ToString();

        //    var Formulariovar = Formulario.AllKeys;

        //    return RedirectToAction("BandejaIndex");
        //}
        public ActionResult DetalleSolicitudActualizacion()
        {
            FiltrosPeticion DetalleDePeticion = new FiltrosPeticion();
            clsPeticion PEntrada = new clsPeticion();
            pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Detalle_Result DetallePeticion =
            new pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Detalle_Result();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();

            PEntrada.IdPeticion = 53;

            DetallePeticion = BandejaDePeticionesc.Obtener_Peticiones_DetalleRdn
            (PEntrada, errorProcedimientoAlmacenado).FirstOrDefault();

            #region Catalogos
            clsGenero cGenero = new clsGenero();
            cGenero.IdGenero = null;
            CrudGeneroRdn catGenero = new CrudGeneroRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Generos_Result> respGenero =
            new List<pa_PeticionesWeb_Catalogos_Obtener_Generos_Result>();
            respGenero = catGenero.solicitarGeneros(cGenero, errorProcedimientoAlmacenado);
            ViewBag.IdGenero = new SelectList(respGenero, "IdGenero", "Nombre");

            clsTipoDerechoHabiente cTipoDereh = new clsTipoDerechoHabiente();
            cTipoDereh.IdTipoDerechohabiente = null;
            CatalogoTipoDerechoHabienteRdn catTipoDerecoh = new CatalogoTipoDerechoHabienteRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_TiposDerhabiente_Result> CatalogoTipoDerecoh =
            new List<pa_PeticionesWeb_Catalogos_Obtener_TiposDerhabiente_Result>();
            CatalogoTipoDerecoh = catTipoDerecoh.solicitarTipoDerechohabiente(cTipoDereh, errorProcedimientoAlmacenado);
            ViewBag.IdTipoDerechohabiente = new SelectList(CatalogoTipoDerecoh, "IdTipoDerechohabiente", "Nombre");

            clsEstado cEstado = new clsEstado();
            cEstado.IdPais = 1;
            CatalogoEstadoRdn catEstado = new CatalogoEstadoRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Estados_Result> CatalogoEstado =
            new List<pa_PeticionesWeb_Catalogos_Obtener_Estados_Result>();
            CatalogoEstado = catEstado.solicitarEstados(cEstado, errorProcedimientoAlmacenado);
            ViewBag.CatalogoEstado = new SelectList(CatalogoEstado, "IdEstado", "Nombre");

            clsTipoOpinion cTipoOpinion = new clsTipoOpinion();
            cTipoOpinion.IdTiposOpinion = null;
            CatalogoTipoOpinionRdn catTipoOpinion = new CatalogoTipoOpinionRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_TiposOpinion_Result> CatalogoTipoOpinion =
            new List<pa_PeticionesWeb_Catalogos_Obtener_TiposOpinion_Result>();
            CatalogoTipoOpinion = catTipoOpinion.solicitarTipoOpinion(cTipoOpinion, errorProcedimientoAlmacenado);
            ViewBag.CatalogoTipoOpinion = new SelectList(CatalogoTipoOpinion, "IdTipoOpinion", "Nombre");

            clsCausaAsunto cCausaAsunto = new clsCausaAsunto();
            cCausaAsunto.IdCausaAsunto = null;
            CatalogoCausasAsuntoRdn catCausaAsunto = new CatalogoCausasAsuntoRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_CausasAsunto_Result> CatalogoCausasAsunto =
            new List<pa_PeticionesWeb_Catalogos_Obtener_CausasAsunto_Result>();
            CatalogoCausasAsunto = catCausaAsunto.solicitarCausasAsunto(cCausaAsunto, errorProcedimientoAlmacenado);
            ViewBag.CatalogoCausasAsunto = new SelectList(CatalogoCausasAsunto, "IdCausaAsunto", "Nombre");

            clsServicioHecho cServHecho = new clsServicioHecho();
            cServHecho.IdServicioHecho = null;
            CatalogoServiciosHechosRdn catServHecho = new CatalogoServiciosHechosRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_ServiciosHechos_Result> CatalogoServHecho =
            new List<pa_PeticionesWeb_Catalogos_Obtener_ServiciosHechos_Result>();
            CatalogoServHecho = catServHecho.solicitarServiciosHecho(cServHecho, errorProcedimientoAlmacenado);
            ViewBag.CatalogoServHecho = new SelectList(CatalogoServHecho, "IdServicioHecho", "Nombre");
            #endregion

            return View(DetallePeticion);
        }

        public ActionResult MenuDetalle(clsPeticion objPeticion)
        {
            FiltrosPeticion DetalleDePeticion = new FiltrosPeticion();
            clsPeticion PEntrada = new clsPeticion();
            pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Detalle_Result DetallePeticion =
            new pa_PeticionesWeb_Bandeja_Peticiones_Obtener_Peticiones_Detalle_Result();
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();

            string FolioPeticion = Request["IdFolioPar"].ToString();
            string IdUPS = Request["IdUPSPar"].ToString();
            TempData["IdPeticion"] = Request["IdPeticion"].ToString(); ;
            string OcultaMenu = string.Empty;


            PEntrada.IdPeticion = Convert.ToInt32(Request["IdPeticion"]);

            DetallePeticion = BandejaDePeticionesc.Obtener_Peticiones_DetalleRdn
            (PEntrada, errorProcedimientoAlmacenado).FirstOrDefault();

            if ((DetallePeticion.IdEstatusInterno < 2))// & (DetallePeticion.IdOperador == IdUsuarioIniciodeSeseion))
            {
                OcultaMenu = "hidden='hidden'";
                @ViewBag.OcultaTab = OcultaMenu;
            }

            if ((DetallePeticion.IdEstatusInterno != 4))// & (DetallePeticion.IdOperador == IdUsuarioIniciodeSeseion))
            {
                OcultaMenu = "hidden='hidden'";
                @ViewBag.BotonCerrarPeticion = OcultaMenu;
            }

            if ((DetallePeticion.IdEstatusInterno == 4))// & (DetallePeticion.IdOperador == IdUsuarioIniciodeSeseion))
            {
                OcultaMenu = "hidden='hidden'";
                @ViewBag.OcultaTab = OcultaMenu;
            }



            if ((DetallePeticion.IdEstatusInterno == 5))// & (DetallePeticion.IdOperador == IdUsuarioIniciodeSeseion))
            {
                OcultaMenu = "hidden='hidden'";
                @ViewBag.BotonCerrarPeticion = OcultaMenu;
                @ViewBag.OcultaTab = OcultaMenu;
            }




            #region Catalogos
            clsGenero cGenero = new clsGenero();
            cGenero.IdGenero = null;
            CrudGeneroRdn catGenero = new CrudGeneroRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Generos_Result> respGenero =
            new List<pa_PeticionesWeb_Catalogos_Obtener_Generos_Result>();
            respGenero = catGenero.solicitarGeneros(cGenero, errorProcedimientoAlmacenado);
            ViewBag.IdGenero = new SelectList(respGenero, "IdGenero", "Nombre");

            clsTipoDerechoHabiente cTipoDereh = new clsTipoDerechoHabiente();
            cTipoDereh.IdTipoDerechohabiente = null;
            CatalogoTipoDerechoHabienteRdn catTipoDerecoh = new CatalogoTipoDerechoHabienteRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_TiposDerhabiente_Result> CatalogoTipoDerecoh =
            new List<pa_PeticionesWeb_Catalogos_Obtener_TiposDerhabiente_Result>();
            CatalogoTipoDerecoh = catTipoDerecoh.solicitarTipoDerechohabiente(cTipoDereh, errorProcedimientoAlmacenado);
            ViewBag.IdTipoDerechohabiente = new SelectList(CatalogoTipoDerecoh, "IdTipoDerechohabiente", "Nombre");

            clsEstado cEstado = new clsEstado();
            cEstado.IdPais = 1;
            CatalogoEstadoRdn catEstado = new CatalogoEstadoRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Estados_Result> CatalogoEstado =
            new List<pa_PeticionesWeb_Catalogos_Obtener_Estados_Result>();
            CatalogoEstado = catEstado.solicitarEstados(cEstado, errorProcedimientoAlmacenado);
            ViewBag.CatalogoEstado = new SelectList(CatalogoEstado, "IdEstado", "Nombre");

            clsTipoOpinion cTipoOpinion = new clsTipoOpinion();
            cTipoOpinion.IdTiposOpinion = null;
            CatalogoTipoOpinionRdn catTipoOpinion = new CatalogoTipoOpinionRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_TiposOpinion_Result> CatalogoTipoOpinion =
            new List<pa_PeticionesWeb_Catalogos_Obtener_TiposOpinion_Result>();
            CatalogoTipoOpinion = catTipoOpinion.solicitarTipoOpinion(cTipoOpinion, errorProcedimientoAlmacenado);
            ViewBag.CatalogoTipoOpinion = new SelectList(CatalogoTipoOpinion, "IdTipoOpinion", "Nombre");

            clsCausaAsunto cCausaAsunto = new clsCausaAsunto();
            cCausaAsunto.IdCausaAsunto = null;
            CatalogoCausasAsuntoRdn catCausaAsunto = new CatalogoCausasAsuntoRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_CausasAsunto_Result> CatalogoCausasAsunto =
            new List<pa_PeticionesWeb_Catalogos_Obtener_CausasAsunto_Result>();
            CatalogoCausasAsunto = catCausaAsunto.solicitarCausasAsunto(cCausaAsunto, errorProcedimientoAlmacenado);
            ViewBag.CatalogoCausasAsunto = new SelectList(CatalogoCausasAsunto, "IdCausaAsunto", "Nombre");

            clsServicioHecho cServHecho = new clsServicioHecho();
            cServHecho.IdServicioHecho = null;
            CatalogoServiciosHechosRdn catServHecho = new CatalogoServiciosHechosRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_ServiciosHechos_Result> CatalogoServHecho =
            new List<pa_PeticionesWeb_Catalogos_Obtener_ServiciosHechos_Result>();
            CatalogoServHecho = catServHecho.solicitarServiciosHecho(cServHecho, errorProcedimientoAlmacenado);
            ViewBag.CatalogoServHecho = new SelectList(CatalogoServHecho, "IdServicioHecho", "Nombre");
            #endregion





            return View(DetallePeticion);
        }

        public ActionResult CerrarPeticion()
        {
            //TempData["IdPeticion"] = Request["IdPeticion"].ToString();

            #region Cerrar Peticion
            //BandejaDePeticionesRdn objBandejaDePeticionesRdn = new BandejaDePeticionesRdn();
            clsPeticion objPeticion = new clsPeticion();
            ErrorProcedimientoAlmacenado ParametrosError = new ErrorProcedimientoAlmacenado();

            objPeticion.IdPeticion = Convert.ToInt32(TempData["IdPeticion"]);
            objPeticion.IdOperador = 2;
            int resp = 0;
            resp = BandejaDePeticionesc.ConcluirCerrar_PeticionRdn(objPeticion, ParametrosError);

            //TempData["IdPeticion"] = null;
            #endregion

            return RedirectToAction("BandejaIndex");
        }




    }
}