﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.Catalogos;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers.Catalogos
{
    public class CatalogoTiposPersonalController : Controller
    {
        // GET: CatalogoTiposPersonal
        public ActionResult Index()
        {
            return View();
        }


        /// <summary>
        /// Obtiene el catálogo de tipo de personal
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult Obtener_TiposPersonal()
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            CatalogoTiposPersonalRdn objTiposPersonalRdn = new CatalogoTiposPersonalRdn();
            //List<object> personal = new List<object>();
            var TiposPersonal = objTiposPersonalRdn.Obtener_TiposPersonalRdn(errorProcedimientoAlmacenado).ToList();
            return Json(TiposPersonal, JsonRequestBehavior.AllowGet);
        }


    }
}