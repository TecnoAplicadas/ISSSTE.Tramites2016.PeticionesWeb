﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.Catalogos;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers
{
    public class CausaAsuntoController : Controller
    {
        CatalogoCausasAsuntoRdn CausaAsuntoRdn = new CatalogoCausasAsuntoRdn();

        // GET: CausaAsunto
        public ActionResult Index()
        {
            clsCausaAsunto CausasAsun = new clsCausaAsunto();
            CausasAsun.IdCausaAsunto = null;

            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();

            var resultado = CausaAsuntoRdn.solicitarCausasAsunto(CausasAsun, errorProcedimientoAlmacenado);

            return View();
        }
    }
}