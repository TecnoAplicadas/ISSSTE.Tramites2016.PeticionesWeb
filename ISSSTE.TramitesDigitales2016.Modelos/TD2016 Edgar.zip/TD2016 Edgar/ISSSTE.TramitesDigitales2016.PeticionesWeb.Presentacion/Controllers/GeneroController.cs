﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.Catalogos;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers
{
    public class GeneroController : Controller
    {
        CrudGeneroRdn GeneroRdn = new CrudGeneroRdn();

        // GET: Genero
        public ActionResult Index()
        {
            Genero genero = new Genero();
            genero.IdGenero = 1;

         ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
         //errorProcedimientoAlmacenado.Inicializar();

         //errorProcedimientoAlmacenado.Numero = new System.Data.Entity.Core.Objects.ObjectParameter("pi_error_numero", typeof(Int32));
         //errorProcedimientoAlmacenado.Numero.Value = -1;

         //errorProcedimientoAlmacenado.Mensaje = 

         var resultado = GeneroRdn.solicitarGeneros(genero, errorProcedimientoAlmacenado);

            return View();
        }
    }
}