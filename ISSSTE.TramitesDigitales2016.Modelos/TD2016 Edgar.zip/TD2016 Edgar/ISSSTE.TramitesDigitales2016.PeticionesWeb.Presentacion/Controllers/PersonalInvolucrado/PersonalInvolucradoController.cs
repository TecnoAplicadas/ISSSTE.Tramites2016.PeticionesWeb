﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.PersonalInvolucrado;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas;


namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers.PersonalInvolucrado
{
    public class PersonalInvolucradoController : Controller
    {
        // GET: PersonalInvolucrado
        public ActionResult Index()
        {
            return View();
        }


        /// <summary>
        /// Obtiene el personal involucrado en una petición
        /// </summary>
        /// <param name="IdPeticion"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult Obtener_PersonalInvolucrado(int IdPeticion)
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            PersonalInvolucradoRdn objPersonalInvoluvradoRdn = new PersonalInvolucradoRdn();
            Modelos.ClasesConcretas.clsPeticion objPeticion = new Modelos.ClasesConcretas.clsPeticion();
            objPeticion.IdPeticion = IdPeticion;
            //List<object> personal = new List<object>();
            var personal = objPersonalInvoluvradoRdn.Obtener_PersonalInvolucradoRdn(objPeticion, errorProcedimientoAlmacenado).ToList();
            return Json(personal, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// Agrega el personal involucrado a una petición
        /// La clase involucrado que se pasa como parámetro debe contener: 
        /// IdPeticion, Nombre, ApellidoPaterno, ApellidoMaterno, IdTipoPersonal, IdUsuarioRegistro
        /// </summary>
        /// <param name="involucrado"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Insertar_PersonalInvolucrado(clsDetallePeticionInvolucrado involucrado)
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            PersonalInvolucradoRdn objPersonalInvoluvradoRdn = new PersonalInvolucradoRdn();

            int resp = objPersonalInvoluvradoRdn.Insertar_PersonalInvolucradoRdn(involucrado, errorProcedimientoAlmacenado);
            return Json(resp, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// Elimina el personal involucrado de una petición
        /// </summary>
        /// <param name="IdPeticion"></param>
        /// <param name="IdInvolucrado"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Eliminar_PersonalInvolucrado(int IdPeticion, int IdInvolucrado)
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            PersonalInvolucradoRdn objPersonalInvoluvradoRdn = new PersonalInvolucradoRdn();
            clsDetallePeticionInvolucrado involucrado = new clsDetallePeticionInvolucrado();
            involucrado.IdPeticion = IdPeticion;
            involucrado.IdInvolucrado = IdInvolucrado;

            int resp = objPersonalInvoluvradoRdn.Eliminar_PersonalInvolucradoRdn(involucrado, errorProcedimientoAlmacenado);
            return Json(resp, JsonRequestBehavior.AllowGet);
        }

    }
}