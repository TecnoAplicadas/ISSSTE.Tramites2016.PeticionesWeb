﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas;
using ISSSTE.TramitesDigitales2016.Modelos.Contextos;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.Catalogos;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.RegistroPeticion;


namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers.Peticiones
{
    public class SolicitudPeticionController : Controller
    {
        // GET: SolicitudPeticion
        // GET: Prueba     
        public JsonResult CatalogoGenero()
        {

            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsGenero cGenero = new clsGenero();
            cGenero.IdGenero = null;
            CrudGeneroRdn catGenero = new CrudGeneroRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Generos_Result> respGenero = new List<pa_PeticionesWeb_Catalogos_Obtener_Generos_Result>();

            respGenero = catGenero.solicitarGeneros(cGenero, errorErrror);

            return Json(respGenero, JsonRequestBehavior.AllowGet);


        }
        public JsonResult GetTipoDerechoabiente()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsTipoDerechoHabiente cTipoDereh = new clsTipoDerechoHabiente();
            cTipoDereh.IdTipoDerechohabiente = null;
            CatalogoTipoDerechoHabienteRdn catTipoDerecoh = new CatalogoTipoDerechoHabienteRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_TiposDerhabiente_Result> respGenero = new List<pa_PeticionesWeb_Catalogos_Obtener_TiposDerhabiente_Result>();
            respGenero = catTipoDerecoh.solicitarTipoDerechohabiente(cTipoDereh, errorErrror);

            return Json(respGenero, JsonRequestBehavior.AllowGet);

        }
        public JsonResult GetUnidadAdministrativa()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsUnidadAdministrativa cUnidadAdm = new clsUnidadAdministrativa();
            cUnidadAdm.IdUnidadAdministrativa = null;
            CatalogoUnidadAdministrativaRdn catUnidadAdm = new CatalogoUnidadAdministrativaRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_UndadesAdministrativas_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_UndadesAdministrativas_Result>();
            respuesta = catUnidadAdm.solicitarUnidadAdministrativa(cUnidadAdm, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);

        }
        public JsonResult GetTipoOpinion()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsTipoOpinion cTipoOpinion = new clsTipoOpinion();
            cTipoOpinion.IdTiposOpinion = null;
            CatalogoTipoOpinionRdn catTipoOpinion = new CatalogoTipoOpinionRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_TiposOpinion_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_TiposOpinion_Result>();
            respuesta = catTipoOpinion.solicitarTipoOpinion(cTipoOpinion, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);

        }
        public JsonResult GetCausaAsunto()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsCausaAsunto cCausaAsunto = new clsCausaAsunto();
            cCausaAsunto.IdCausaAsunto = null;
            CatalogoCausasAsuntoRdn catCausaAsunto = new CatalogoCausasAsuntoRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_CausasAsunto_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_CausasAsunto_Result>();
            respuesta = catCausaAsunto.solicitarCausasAsunto(cCausaAsunto, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);

        }
        public JsonResult GetServicioHechos()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsServicioHecho cServHecho = new clsServicioHecho();
            cServHecho.IdServicioHecho = null;
            CatalogoServiciosHechosRdn catServHecho = new CatalogoServiciosHechosRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_ServiciosHechos_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_ServiciosHechos_Result>();
            respuesta = catServHecho.solicitarServiciosHecho(cServHecho, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);
        }
        //public JsonResult CatalogoUnidadesPrestadorasDeServicios(int pIdUnidadAdministrativa)
        //{
        //    ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
        //    clsUnidadPrestadoraServicio cUndPrestServ = new clsUnidadPrestadoraServicio();
        //    cUndPrestServ.IdUnidadAdministrativa = 1;//pIdUnidadAdministrativa;
        //    cUndPrestServ.EstatusRegistro = "A";

        //    CatalogoUnidadesPrestadoraServicioRdn catServHecho = new CatalogoUnidadesPrestadoraServicioRdn();

        //    List<pa_PeticionesWeb_Catalogos_Obtener_UndsPrestadoraServicios_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_UndsPrestadoraServicios_Result>();
        //    respuesta = catServHecho.solicitarUnidadPrestServ(cUndPrestServ, errorErrror);

        //    return Json(respuesta, JsonRequestBehavior.AllowGet);
        //}
        //public JsonResult GetUnidPrestServ(int pIdUnidadAdministrativa)
        //{
        //    ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
        //    clsUnidadPrestadoraServicio cUndPrestServ = new clsUnidadPrestadoraServicio();
        //    cUndPrestServ.IdUnidadAdministrativa = 1;//pIdUnidadAdministrativa;
        //    cUndPrestServ.EstatusRegistro = "A";

        //    CatalogoUnidadesPrestadoraServicioRdn catServHecho = new CatalogoUnidadesPrestadoraServicioRdn();

        //    List<pa_PeticionesWeb_Catalogos_Obtener_UndsPrestadoraServicios_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_UndsPrestadoraServicios_Result>();
        //    respuesta = catServHecho.solicitarUnidadPrestServ(cUndPrestServ, errorErrror);

        //    return Json(respuesta, JsonRequestBehavior.AllowGet);
        //}
        public JsonResult GetPais()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsPais cPais = new clsPais();
            cPais.IdPais = null;
            CatalogoPaisRdn catPais = new CatalogoPaisRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Paises_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_Paises_Result>();
            respuesta = catPais.solicitarPais(cPais, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetEstado(int pIdPais)
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsEstado cEstado = new clsEstado();
            cEstado.IdPais = pIdPais;
            CatalogoEstadoRdn catEstado = new CatalogoEstadoRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Estados_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_Estados_Result>();
            respuesta = catEstado.solicitarEstados(cEstado, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetMunicipio(int pIdEstado)
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsMunicipio cMunicipio = new clsMunicipio();
            cMunicipio.IdEstado = pIdEstado;
            CatalogoMunicipioRdn catEstado = new CatalogoMunicipioRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_Municipios_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_Municipios_Result>();
            respuesta = catEstado.solicitarEstados(cMunicipio, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCodidoPostal(int pIdMunicipio)
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsCodigoPostal cCodPostal = new clsCodigoPostal();
            cCodPostal.IdMunicipio = pIdMunicipio;
            cCodPostal.EstatusRegistro = "A";
            CatalogoCodigoPostalRdn catEstado = new CatalogoCodigoPostalRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_CodigosPostales_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_CodigosPostales_Result>();
            respuesta = catEstado.solicitarCodigoPostal(cCodPostal, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetPoblacionColonia()
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            clsPoblacionOColonia cPoblCol = new clsPoblacionOColonia();
            cPoblCol.IdCodigoPostal = 14248;//pIdCodigoPostal;
            cPoblCol.EstatusRegistro = "A";
            CatalogoPoblacionColoniaRdn catPoblCol = new CatalogoPoblacionColoniaRdn();
            List<pa_PeticionesWeb_Catalogos_Obtener_PoblacionesColonias_Result> respuesta = new List<pa_PeticionesWeb_Catalogos_Obtener_PoblacionesColonias_Result>();
            respuesta = catPoblCol.solicitarPoblacionColonia(cPoblCol, errorErrror);

            return Json(respuesta, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GuardarPeticion(
           //string pCurp,
           //string pRfc,
           //string pNombre,
           //string pApellidoPaterno,
           //string pApellidoMaterno,
           //int pIdGenero,
           //int pIdTipoDerechohabiente,
           //int pIdPoblacionOColonia,
           //string pCalle,
           //string pNumeroExterior,
           //string pNumeroInterior,
           //string pLada,
           //string pTelefonoFijo,
           //string pTelefonoMovil,
           //string pCorreoElectronico,
           //string pCurpAfec,
           //string pRfcAfec,
           //string pNombreAfec,
           //string pApellidoPaternoAfec,
           //string pApellidoMaternoAfec,
           //int pIdGeneroAfec,
           //int pIdTipoDerechohabienteAfec,
           //string pTelefonoFijoAfec,
           //string pCorreoElectronicoAfec,
           //int pIdUnidadPrestadoraServicio,
           //int pIdServicioHecho,
           //int pIdCausaAsunto,
           //DateTime pFechaHechos,
           //string pDescripcion,
           //int pIdFlujoNotificacion,
           //int pIdFlujoRecordatorio,
           //int pIdFlujoSemaforo,
           //int pIdFlujoEstatus,
           //int pIdEstatusInterno
           )
        {
            ErrorProcedimientoAlmacenado errorErrror = new ErrorProcedimientoAlmacenado();
            Peticion cPeticion = new Peticion();
            cPeticion.Peticionario = new Peticionario();
            cPeticion.Peticionario.Curp = "ABMA800502HDFNMR67";
            cPeticion.Peticionario.Rfc = "AAMA800502";
            cPeticion.Peticionario.Nombre = "Iván xxx";
            cPeticion.Peticionario.ApellidoPaterno = "Gonzalez";
            cPeticion.Peticionario.ApellidoMaterno = "Martinez";
            cPeticion.Peticionario.IdGenero = 1;
            cPeticion.Peticionario.IdTipoDerechohabiente = 1;
            cPeticion.Peticionario.IdPoblacionOColonia = 1854;
            cPeticion.Peticionario.Calle = "Siempre Viva";
            cPeticion.Peticionario.NumeroExterior = "295";
            cPeticion.Peticionario.NumeroInterior = "3";
            cPeticion.Peticionario.Lada = "722";
            cPeticion.Peticionario.TelefonoFijo = "45687123";
            cPeticion.Peticionario.TelefonoMovil = "7856841238";
            cPeticion.Peticionario.CorreoElectronico = "Peticionario@dominio.com";
            cPeticion.Afectado = new Afectado();
            cPeticion.Afectado.Curp = "BBWE800425HDFNMR04";
            cPeticion.Afectado.Rfc = "MMWE800425";
            cPeticion.Afectado.Nombre = "Benito";
            cPeticion.Afectado.ApellidoPaterno = "Pérez";
            cPeticion.Afectado.ApellidoMaterno = "Galdos";
            cPeticion.Afectado.IdGenero = 2;
            cPeticion.Afectado.IdTipoDerechohabiente = 3;
            cPeticion.Afectado.TelefonoFijo = "45788956";
            cPeticion.Afectado.CorreoElectronico = "Afectado@dominio.com";

            cPeticion.IdUnidadPrestadoraServicio = 1; //unidad prestadora de servicio
            cPeticion.IdServicioHecho = 77;
            cPeticion.IdCausaAsunto = 2;
            cPeticion.FechaHechos = DateTime.Now;
            cPeticion.Descripcion = "Prueba de Guardado ";
            cPeticion.IdFlujoNotificacion = 1;
            cPeticion.IdFlujoRecordatorio = 1;
            cPeticion.IdFlujoSemaforo = 1;
            cPeticion.IdFlujoEstatus = 1;
            cPeticion.IdEstatusInterno = 1;

            //cPeticion.Peticionario = new Peticionario();
            //cPeticion.Peticionario.Curp = pCurp;
            //cPeticion.Peticionario.Rfc = pRfc;
            //cPeticion.Peticionario.Nombre = pNombre;
            //cPeticion.Peticionario.ApellidoPaterno = pApellidoPaterno;
            //cPeticion.Peticionario.ApellidoMaterno = pApellidoMaterno;
            //cPeticion.Peticionario.IdGenero = pIdGenero;
            //cPeticion.Peticionario.IdTipoDerechohabiente = pIdTipoDerechohabiente;
            //cPeticion.Peticionario.IdPoblacionOColonia = pIdPoblacionOColonia;
            //cPeticion.Peticionario.Calle = pCalle;
            //cPeticion.Peticionario.NumeroExterior = pNumeroExterior;
            //cPeticion.Peticionario.NumeroInterior = pNumeroInterior;
            //cPeticion.Peticionario.Lada = pLada;
            //cPeticion.Peticionario.TelefonoFijo = pTelefonoFijo;
            //cPeticion.Peticionario.TelefonoMovil = pTelefonoMovil;
            //cPeticion.Peticionario.CorreoElectronico = pCorreoElectronico;
            //cPeticion.Afectado = new Afectado();
            //cPeticion.Afectado.Curp = pCurpAfec;
            //cPeticion.Afectado.Rfc = pRfcAfec;
            //cPeticion.Afectado.Nombre = pNombreAfec;
            //cPeticion.Afectado.ApellidoPaterno = pApellidoPaternoAfec;
            //cPeticion.Afectado.ApellidoMaterno = pApellidoMaternoAfec;
            //cPeticion.Afectado.IdGenero = pIdGeneroAfec;
            //cPeticion.Afectado.IdTipoDerechohabiente = pIdTipoDerechohabienteAfec;
            //cPeticion.Afectado.TelefonoFijo = pTelefonoFijoAfec;
            //cPeticion.Afectado.CorreoElectronico = pCorreoElectronicoAfec;
            //cPeticion.IdUnidadPrestadoraServicio = pIdUnidadPrestadoraServicio;
            //cPeticion.IdServicioHecho = pIdServicioHecho;
            //cPeticion.IdCausaAsunto = pIdCausaAsunto;
            //cPeticion.FechaHechos = pFechaHechos;
            //cPeticion.Descripcion = pDescripcion;
            //cPeticion.IdFlujoNotificacion = pIdFlujoNotificacion;
            //cPeticion.IdFlujoRecordatorio = pIdFlujoRecordatorio;
            //cPeticion.IdFlujoSemaforo = pIdFlujoSemaforo;
            //cPeticion.IdFlujoEstatus = pIdFlujoEstatus;
            //cPeticion.IdEstatusInterno = pIdEstatusInterno;

            PeticionRdn GuardarPeticion = new PeticionRdn();
            GuardarPeticion.SalvarPeticion(cPeticion, errorErrror);

            ViewBag.Mensaje = errorErrror.Mensaje.Value.ToString();

            return View();
        }


    }
}