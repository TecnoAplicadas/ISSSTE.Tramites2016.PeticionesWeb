﻿using ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Models;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Reportes;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Reportes.ServiciosReportes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers.ReportesControles
{
    public class ReportesController : Controller
    {
      IGenerarReporte generar = new GenerarReporte();
      [HttpGet]
        public ActionResult Reportes()
        {
            CargaCatalogoReportesPdf vmr = new CargaCatalogoReportesPdf();
            var viewModel = vmr.CragarCatalogosPdf();
            return View(viewModel);
        }
        [HttpPost]
        public ActionResult Reportes(ViewModelReporteTipoOpinionCaptacion vmr) {
         if (vmr.ReporteNumero == 3)
         {
            return generar.GenerarReporteCaptacion(vmr.FiltroPdf);
         }
         //else if (vmr.ReporteNumero == 2)
         //{
         //   return generar.GenerarReporteTipoOpinion(vmr.FiltroPdf);
         //}
         return RedirectToAction("Reportes");
      }
    }
}