﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.SeguimientoOperador;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Controllers.SeguimientoOperador
{
    public class SeguimientoOperadorController : Controller
    {
        // GET: SeguimientoOperador
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Consulta  los registros de seguimiento de una petición
        /// </summary>
        /// <param name="IdPeticion"></param>
        /// <param name="IdOperador"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult Obtener_SeguimientoOperador(int IdPeticion, int IdOperador)
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            SeguimientoOperadorRdn objSeguimientoOperadorRdn = new SeguimientoOperadorRdn();
            clsDetallePeticionSeguimieto objSeguimiento = new clsDetallePeticionSeguimieto();
            objSeguimiento.IdPeticion = IdPeticion;
            objSeguimiento.IdUsuario = IdOperador;

            //List<object> personal = new List<object>();
            var seguimiento = objSeguimientoOperadorRdn.Obtener_SeguimientoOperadorRdn(objSeguimiento, errorProcedimientoAlmacenado).ToList();
            return Json(seguimiento, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Agrega un registro de seguimiento a la petición
        /// El parámetro seguimiento debe incluir: IdPeticion, IdOperador, Comentarios
        /// </summary>
        /// <param name="seguimiento"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Insertar_SeguimientoOperador(clsDetallePeticionSeguimientoOperador seguimiento)
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            SeguimientoOperadorRdn objSeguimientoOperadorRdn = new SeguimientoOperadorRdn();

            int resp = objSeguimientoOperadorRdn.Insertar_SeguimientoOperadorRdn(seguimiento, errorProcedimientoAlmacenado);
            return Json(resp, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Elimina el seguimiento del operador que se pasa como parámetro
        /// El parámetro seguimiento debe incluir: IdPeticion, IdSeguimiento, IdSeguimientoOperador, IdOperador
        /// </summary>
        /// <param name="seguimiento"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Eliminar_SeguimientoOperador(clsDetallePeticionSeguimientoOperador seguimiento)
        {
            ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
            SeguimientoOperadorRdn objSeguimientoOperadorRdn = new SeguimientoOperadorRdn();

            int resp = objSeguimientoOperadorRdn.Eliminar_SeguimientoOperadorRdn(seguimiento, errorProcedimientoAlmacenado);
            return Json(resp, JsonRequestBehavior.AllowGet);
        }

    }
}