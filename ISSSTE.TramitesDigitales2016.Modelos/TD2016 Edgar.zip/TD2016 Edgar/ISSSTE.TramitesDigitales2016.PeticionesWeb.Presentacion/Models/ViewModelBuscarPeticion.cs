﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using ISSSTE.TramitesDigitales2016.Modelos.Contextos;
using ISSSTE.TramitesDigitales2016.Modelos.ClasesConcretas;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Models
{
    public class ViewModelBuscarPeticion
    {
        public clsUsuario Usuario { get;  set; }
        public clsPeticion Peticiones { get; set; }
        public clsPeticionario Peticionario { get; set; }
        public clsAfectado afectado { get; set; }
        public pa_PeticionesWeb_Catalogos_EsatusInterno_Result CataloEstatus { get; set; }

    }
}