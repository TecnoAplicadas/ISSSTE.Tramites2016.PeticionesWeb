﻿using ISSSTE.TramitesDigitales2016.Modelos.Contextos;
using ISSSTE.TramitesDigitales2016.Modelos.Modelos.ManejoErrores;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Procesos.Modulos.Reportes.FiltroReportes;
using ISSSTE.TramitesDigitales2016.PeticionesWeb.Rdn.Modulos.ListarReporte;
using Microsoft.Reporting.WebForms;
using System.Web.Mvc;
using System;
//using Microsoft.

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Reportes.ServiciosReportes
{
   public class GenerarReporte :IGenerarReporte
   {
      ErrorProcedimientoAlmacenado errorProcedimientoAlmacenado = new ErrorProcedimientoAlmacenado();
      //DataTable
      public FileContentResult GenerarReporteCaptacion(FiltroReportePorTiposOpinionCaptacion pi)
      {
         ListaReporteCaptacion reporteCaptacionList = new Rdn.Modulos.ListarReporte.ListaReporteCaptacion();
         var list = reporteCaptacionList.solicitarReporteCaptacion(pi, errorProcedimientoAlmacenado);
         if (pi.FechaInicio == pi.FechaFin)
            pi.FechaFin.AddDays(1);
         using (TramitesDigitalesEntities _entities = new TramitesDigitalesEntities())
         {
            Warning[] warnings;
            string mimeType;
            string[] streamids;
            string encoding;
            string filenameExtension;

            var viewer = new ReportViewer();
            viewer.LocalReport.ReportPath = @"Reportes\ServiciosReportes\PlantillasReportes\ReportePorCaptacion.rdlc";
            ReportDataSource RDS = new ReportDataSource("DataSetReporteCaptacion", list);
            viewer.LocalReport.DataSources.Add(RDS);
            viewer.LocalReport.Refresh();
            var bytes = viewer.LocalReport.Render("pdf", null, out mimeType, out encoding, out filenameExtension, out streamids, out warnings);

            return new FileContentResult(bytes, mimeType);
         }
      }

      public FileContentResult GenerarReporteTipoOpinion(FiltroReportePorTiposOpinionCaptacion pi)
      {
         throw new NotImplementedException();
      }

      //public FileContentResult GenerarReporteTipoOpinion(FiltroReportePorTiposOpinionCaptacion pi)
      //{
      //   ListaReporteTipoOpinion reporteCaptacionList = new ListaReporteTipoOpinion();
      //   var list = reporteCaptacionList.solicitarPorOpinion(pi, errorProcedimientoAlmacenado);
      //   using (TramitesDigitalesEntities _entities = new TramitesDigitalesEntities())
      //   {
      //      Warning[] warnings;
      //      string mimeType;
      //      string[] streamids;
      //      string encoding;
      //      string filenameExtension;

      //      var viewer = new ReportViewer();
      //      viewer.LocalReport.ReportPath = @"Reports\ReportePorOpinion.rdlc";
      //      ReportDataSource RDS = new ReportDataSource("DataSetPorOpinion", list);
      //      viewer.LocalReport.DataSources.Add(RDS);
      //      viewer.LocalReport.Refresh();
      //      var bytes = viewer.LocalReport.Render("pdf", null, out mimeType, out encoding, out filenameExtension, out streamids, out warnings);

      //      return new FileContentResult(bytes, mimeType);
      //   }
      //}
   }
}