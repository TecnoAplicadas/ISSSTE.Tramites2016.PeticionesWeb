﻿using ISSSTE.TramitesDigitales2016.PeticionesWeb.Procesos.Modulos.Reportes.FiltroReportes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ISSSTE.TramitesDigitales2016.PeticionesWeb.Presentacion.Reportes
{
   interface IGenerarReporte
   {
      FileContentResult GenerarReporteCaptacion(FiltroReportePorTiposOpinionCaptacion pi);
      FileContentResult GenerarReporteTipoOpinion(FiltroReportePorTiposOpinionCaptacion pi);
   }
}
